#include <stdio.h>
#include <stdlib.h>

void execution(int tab[], int indic, int *registre);

void affichage(char * ligne, int *registre);
