#include "processeur.h"

void execution(int tab[], int indic, int *registre[]){
	int rd = 0;
	int rs = 0;
	int rt = 0;
	
	switch(indic){

		case 0 :  /*ADD*/
			
			
			/*Affectation rd, rt, rs*/
			rd = *registre[tab[0]];
			rt = *registre[tab[1]];
			rs = *registre[tab[2]];
		
			rd = rt + rs;
			
			printf("rd = %d\n", rd);
			printf("rt = %d\n", rt);
			printf("rs = %d\n", rs);
		
			printf("tab[0] = %d\n", registre[tab[0]]);
			printf("tab[1] = %d\n", tab[1]);
			printf("tab[2] = %d\n", tab[2]);
			
			break;
		
		default :
			printf("Erreur\n");
			break;
	}
	
}

