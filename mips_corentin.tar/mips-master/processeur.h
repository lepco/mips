#include <stdio.h>
#include <stdlib.h>

void execution(int tab[], int indic, int *registre[]);