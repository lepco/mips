#include "fonctions.h"

void lecture(char fichierLecture[100], char inst[100]){
	FILE * fic;
	int i = 0;

	/*ouverture du fichier*/
	fic = fopen(fichierLecture, "r");
	if(fic == NULL){
		perror("Probleme ouverture du fichier en lecture");
		exit(1);
	}

	/*Lecture du fichier*/
	while (!feof(fic)) {
		fscanf(fic, "%c", &inst[i]);

		/*On ne garde pas en memoire les lignes commencant par '#'*/
		if (inst[i] == '#') {
			while (inst[i] != 0x00A) {
				fscanf(fic, "%c", &inst[i]);
			}
		}

		i++;
	}
	printf("%s\n", inst);


	/*Fermeture du fichier*/
	fclose(fic);



}
/*

void separation(instruction);

int ecritureBinaire(int rd, int rt, int rs, int instBin){
	int i = 0;
	switch(i){

		case 0 :
			instBin = instBin | 32;  0000 0000 0000 0000 0000 0000 0010 0000
			instBin = instBin | rd<<11;
			instBin = instBin | rt<<16;
			instBin = instBin | rs<<21;
			break;
		default :
			printf("Erreur");
			break;
	}

	printf("%d\n", instBin);

	return(0);
}

void ecritureFichier(fichierEcriture, instBin);*/
