#include <stdio.h>
#include <stdlib.h>


void lecture(char fichierLecture[100], char inst[100]);

/*void separation(instruction);

int ecritureBinaire(int rd, int rt, int rs, int instBin);

void ecritureFichier(fichierEcriture, instBin);*/
